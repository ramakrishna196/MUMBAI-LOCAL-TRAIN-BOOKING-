# Virtual-Internship---Android-Application-Development-Using-Kotlin
Grocery cart app using Kotlin in the Android Studio platform.

I developed my Govery cart app using Kotlin programming language in Android Studio. There is the process flow that, I implemented in building the app.

![Screenshot (169)](https://user-images.githubusercontent.com/107013994/197048640-abddf713-0b9f-46d6-8100-836cb6ce910c.png)
